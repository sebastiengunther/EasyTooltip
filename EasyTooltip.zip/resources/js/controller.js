define([], function() {

    'use strict';
		
	return function(scope) {
		
	}

});
	
	


